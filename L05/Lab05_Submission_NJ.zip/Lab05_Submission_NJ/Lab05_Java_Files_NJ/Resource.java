
/**
 * Lab 05 Code Exercise 1/2
 * 
 * @author Nathan Jack
 * @version 1.0
 * @since Oct 27, 2020
 * 
 *        Sources: Code base from D2L
 */

public class Resource {

	int counter;
	
	public int increment() {
		return counter++;
	}
	
}
