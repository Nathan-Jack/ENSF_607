
public class Ex_Tester {

	public Ex_Tester() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws InterruptedException {

		RandomNumberExerciseTask1.main(args);
		RandomNumberExerciseTask2.main(args);
		RandomNumberExerciseTask3.main(args);
	}

}
